import React from 'react'

function App() {
  return (
    <div>
      <h1>Welcome to Snookify!</h1>
      <p>Upload your image and start your personalization journey.</p>
    </div>
  )
}

export default App
